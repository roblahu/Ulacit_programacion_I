Cosas por hacer:

- Daniel y Adi instalar base datos
- Crear pagina de pago > Daniel
- Subir validacion actualizada > Gabriel
- Investigar logs y web config; crear codigo y pasarlo a Gabriel que lo pone en el html > Adi
- Actualizar grados > Rolando